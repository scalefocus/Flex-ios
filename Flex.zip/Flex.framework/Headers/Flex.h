//
//  Flex.h
//  Flex
//
//  Created by Nadezhda on 31.07.19.
//  Copyright © 2019 Upnetix. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Flex.
FOUNDATION_EXPORT double FlexVersionNumber;

//! Project version string for Flex.
FOUNDATION_EXPORT const unsigned char FlexVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Flex/PublicHeader.h>


